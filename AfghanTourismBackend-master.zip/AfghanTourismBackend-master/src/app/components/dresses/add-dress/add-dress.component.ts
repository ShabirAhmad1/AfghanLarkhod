import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-add-dress',
  templateUrl: './add-dress.component.html',
  styleUrls: ['./add-dress.component.css']
})
export class AddDressComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }
}
