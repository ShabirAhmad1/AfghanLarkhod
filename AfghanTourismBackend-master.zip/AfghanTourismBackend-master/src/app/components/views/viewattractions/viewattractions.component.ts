import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-viewattractions',
  templateUrl: './viewattractions.component.html',
  styleUrls: ['./viewattractions.component.css']
})
export class ViewAttractionsComponent implements OnInit {
  
  constructor() { }

  
  ngOnInit() {
  }

}
