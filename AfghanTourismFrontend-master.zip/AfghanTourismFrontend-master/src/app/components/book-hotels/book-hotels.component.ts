import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-hotels',
  templateUrl: './book-hotels.component.html',
  styleUrls: ['./book-hotels.component.css']
})
export class BookHotelsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
