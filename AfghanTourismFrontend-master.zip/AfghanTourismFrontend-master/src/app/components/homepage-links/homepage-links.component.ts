import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage-links',
  templateUrl: './homepage-links.component.html',
  styleUrls: ['./homepage-links.component.css']
})
export class HomepageLinksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
