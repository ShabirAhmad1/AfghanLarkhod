import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-cuisines-page',
  templateUrl: './cuisines-page.component.html',
  styleUrls: ['./cuisines-page.component.css']
})
export class CuisinesPageComponent implements OnInit {

  constructor(
  ) { }

  ngOnInit() {
  }
}
