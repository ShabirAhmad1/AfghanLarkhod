import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cultural-dresses-page',
  templateUrl: './cultural-dresses-page.component.html',
  styleUrls: ['./cultural-dresses-page.component.css']
})
export class CulturalDressesPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
