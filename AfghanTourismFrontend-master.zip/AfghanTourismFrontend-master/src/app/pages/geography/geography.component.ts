import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-geography',
  templateUrl: './geography.component.html',
  styleUrls: ['./geography.component.css']
})
export class GeographyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
