import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-attractions-page',
  templateUrl: './top-attractions-page.component.html',
  styleUrls: ['./top-attractions-page.component.css']
})
export class TopAttractionsPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
